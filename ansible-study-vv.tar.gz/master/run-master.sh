#!/bin/bash

#copy sample inventory file 
cat /var/ans-lab/inventory >> /etc/ansible/inventory

#copy agentstart responsible for ssh agent and ssh add to profiles.d and link to .bashrc to start when login to master initiates
cat /var/ans-lab/agentstart >> /etc/profile.d/agentstart
chmod 755 /etc/profile.d/agentstart
rm /root/.bashrc
cd /
ln -s /etc/profile.d/agentstart /root/.bashrc
/usr/sbin/sshd -D
